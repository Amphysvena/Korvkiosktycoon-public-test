export const skillData = {
    throw: {
    name: "Throw",
    img: "Skill 1 - Throw.png",
    description: "Throw the sausage very hard."  
    }
}


//Throw (gör inget nu, det är första skillen men i första versionen av spelet så finns enbart detta så skapa enbart en skill som heter Throw)