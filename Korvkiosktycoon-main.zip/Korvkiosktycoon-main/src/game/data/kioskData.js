export const kioskData = {
    //korvknappar
    korv1: {
      name: 'Cooked hot dog',
      description: 'One generic sausage.',
      img: "src/game/assets/img/equipment/Korvknappar/korv1.png"
    },

    korv2: {
      name: 'Cooked hot dog with ketchup and mustard',
      description: 'This one has taste!',
      img: 'src/game/assets/img/equipment/Korvknappar/korv2.png'
    },

    korv3: {
      name: 'Cooked hot dog with everything',
      description: 'The pinnacle of swedish ingenuity!',
      img: 'src/game/assets/img/equipment/Korvknappar/korv3.png'
    },

    fuskkorv: {
      name: 'The one doG',
      description: 'The Gods use this to test the limits of their Realm.',
      img: "src/game/assets/img/equipment/Korvknappar/korv1.png",
    }

    
    
};