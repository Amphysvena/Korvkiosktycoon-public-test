import { state } from '../state.js';

export function updateBoogie(deltaMs) {
  const delta = deltaMs / 1000; // Convert milliseconds to seconds

  const b = state.boogie;
  if (!b) return;

  const baseRegen = b.regeneration || 0;
  const bonusSum = Object.values(b.regenBonuses || {}).reduce((sum, val) => sum + val, 0);
  const totalRegen = baseRegen + bonusSum;

  if (totalRegen <= 0) return;

  if (b.currentHP < b.maxHP) {
    b.currentHP = Math.min(b.currentHP + totalRegen * delta, b.maxHP);
  }
}


//pseudokod


//Boogie stats: Byråkrat - går sidledes 10 HP, kommer med sitt prat: pratbubbla skickas random neråt mot spelaren
// 1 skada
// drops: ketchup 100% Topphatt 100%
// För denna version så vinner man automatiskt om man har varmkorvbröd equipped och trycker på byråkraten.

//Byråkrat besegrad boolean
//If true = unlock Ärkekrat, drops: ketchup 100% Topphatt 100%

//Ärkekrat boogie stats: (Ärkekrat Går sidledes snabbt med tempoförändringar, Skickar pratbubblor 3 åt gången neråt mot spelaren
//Skada 2
//Immun mot vanlig skada. 
//HP 15)
// I denna version enkel check om man har ketchup och topphatt equippat för att vinna
//Drops 
//Senap 100%
//Recipe för korv med bröd, ketchup, senap 100%

//Ärkekrat besegrad boolean
//if true = Överförmyndare unlock i boogie, Drops Senap 100% Recipe för korv med bröd, ketchup, senap 100%

//Överförmyndare boogie stats: (Står still. Regnar pratbubblor random neråt. 
//Är immun mot allt utom senap i 5 sekunder (gult tecken)
//Är immun mot allt utom ketchup i 5 sekunder (rött tecken)
//Är immun mot all utom vanlig dmg i 5 sekunder (vitt tecken). 
//HP 100
//Pratbubbla dmg 5
//Drops: 
//Secondary Hand bostongurka 100%
//Recipe: Korv med allt 100%
//Pilgrimshatt 100%
//Building permission: Lagerhus 100%)

//Överförmyndare besegrad boolean
//if true: drops Secondary Hand bostongurka, Recipe: Korv med allt, Pilgrimshatt, Building permission