// skillsEngine.js
export function updateSkills(delta) {
  // No logic yet, just a placeholder for future skill updates. hooks any engine updates to the global frame rate
}


//pseudokod

//Equip varmkorbröd första gången: Unlock skill throw (gör inget nu, det är första skillen men i första versionen av spelet så finns enbart detta så skapa enbart en skill som heter Throw)