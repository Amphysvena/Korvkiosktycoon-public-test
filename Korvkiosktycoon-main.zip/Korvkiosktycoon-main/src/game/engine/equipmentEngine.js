

//Pseudokod

//Plastlåda researched i research tab {Plastlåda Varmkorv Equip upplåst}, {Equip interface upplåst}

//Plastlåda put in equipment slot = Låser upp 1. Primary Handvapnet koktkorvbröd

//Byråkrat i boogieEngine besegrad = true:
    //Secondary Equip ketchup unlock (adds 1 ketchup damage), 
    //Hatt equip Topphatt Unlock(Max HP +10)
//

//Ärkekrat besegrad = true  unlocks senap (adds 1 senap damage)

//Överförmyndare besegrad = true unlocks 
    // bostongurka (Adds 1 HP regen)
    // Pilgrimshatt (Max HP +50), 
//

//Fisklåda researched = Unlock Fisklåda (Boogie stats: Ammo cap 100 alla vapen, ammo regen 1 per 5 sec kylskada (25% chans att fienden står still i 1 sekund/ej implementerat)

//Recipe 1 Korv med bröd,ketchup, senap forskat = Unlock  Primaryhand 2.kokt korv med bröd, ketchup senap (Boogie stats 1 normal dmg, 1 senap dmg,1 ketchup dmg)
