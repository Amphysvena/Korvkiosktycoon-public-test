//Detta är övre delen av skärmen, där tabs man gör saker infrån är andra nedre halvan. 

//Tanken är att denna skärm kan ha en primitiv bild eller animation beroende på vilken tab som är aktiverad. Och visa korvinnehav, korvtak och eventuelly korvinkomst. 

//Eventuellt senare om spelutvecklingen fortsätter så kan boogie-duellerna utspelas här. 