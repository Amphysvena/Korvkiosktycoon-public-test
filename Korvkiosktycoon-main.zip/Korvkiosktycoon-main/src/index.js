import { startGame } from './game/main.js';

document.addEventListener('DOMContentLoaded', () => {
  startGame();
});
